    <?php $url_bootstrap = base_url('assets/admin/'); ?>
    <footer class="main-footer">
      <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.0
      </div>
      <strong>Developed by <a href="https://bayusapp.com" target="_blank">Bayu SAPP</a>. &copy; 2020 </strong>
    </footer>
    </div>
    <script src="<?= $url_bootstrap ?>bower_components/jquery/dist/jquery.min.js"></script>
    <script src="<?= $url_bootstrap ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?= $url_bootstrap ?>bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?= $url_bootstrap ?>bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?= $url_bootstrap ?>bower_components/select2/dist/js/select2.full.min.js"></script>
    <script src="<?= $url_bootstrap ?>plugins/sweetalert/sweetalert.min.js"></script>
    <script src="<?= $url_bootstrap ?>plugins/tinymce/js/tinymce/tinymce.min.js"></script>
    <script src="<?= $url_bootstrap ?>plugins/maskmoney/jquery.maskMoney.js"></script>
    <script src="<?= $url_bootstrap ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
    <script src="<?= $url_bootstrap ?>bower_components/fastclick/lib/fastclick.js"></script>
    <script src="<?= $url_bootstrap ?>dist/js/adminlte.min.js"></script>
    <script src="<?= $url_bootstrap ?>custom.js"></script>
    </body>

    </html>